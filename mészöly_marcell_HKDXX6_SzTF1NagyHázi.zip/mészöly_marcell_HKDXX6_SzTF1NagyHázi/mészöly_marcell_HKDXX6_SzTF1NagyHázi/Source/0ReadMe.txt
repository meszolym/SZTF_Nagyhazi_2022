﻿Tedd ebbe a mappába a kiinduló fájlt!

---
A fájlban leírandó változók:
kezdőtőke - pozitív egész szám, maximum 1 073 741 823.
mezők száma - n, amire igaz, hogy n ∈ {Z+ | n>6; n<50; n%4 = 0}.
	A startmezőt a játék autmatikusan generálja és adja hozzá a mezőkhöz!
mezők pénzértékei - pozitív egész számok, maximum 2 147 483 647, pontosvesszővel elválasztva.

A fájl így kell kinézzen:
[kezdőtőke]
[mezők száma]
[1. mező pénzértéke];[2. mező pénzértéke];...;[n. mező pénzértéke]

---

Példa 1:
15000
11
2000;5000;1000;9000;3000;8000;7000;4500;9820;6350;7500

Példa 2:
70000
19
3204;76156;68060;23825;42271;34136;68377;70797;64416;54256;5106;75187;31414;76253;60817;65331;71426;47190;8831